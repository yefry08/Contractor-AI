export const dataFeatures = [
  {
    id: 1,
    image: "medal",
    text: "Aprobado por otros clientes",
    additionalClass: "mt-0",
  },
  {
    id: 2,
    image: "construction",
    text: "Trabajando desde hace 20 años",
    additionalClass: "mt-20",
  },
  {
    id: 3,
    image: "calendar",
    text: "Plataform automática calendario",
    additionalClass: "mt-0",
  },
];
