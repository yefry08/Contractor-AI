export const dataSocialNetworks = [
  {
    id: 1,
    name: "Github",
    icon: "github",
    link: "https://github.com/ratasi",
  },
  {
    id: 2,
    name: "Instagram",
    icon: "instagram",
    link: "https://instagram.com/tarredev",
  },
  {
    id: 3,
    name: "LinkedIn",
    icon: "linkedin",
    link: "https://linkedin.com/rafatarrega",
  },
  {
    id: 4,
    name: "Tik Tok",
    icon: "tiktok",
    link: "https://tiktok.com/tarredev",
  },
  {
    id: 5,
    name: "Youtube",
    icon: "youtube",
    link: "https://youtube.com/@tarredev",
  },
];
